------------------
Facebook GUI PSD
Designed by Surgeworks (http://www.surgeworks.com)
------------------

Dear friends,

thank you for downloading this file.

This set has been brought to you by SmashingMagazine.com and is released for free - it is free to use in any personal or commercial projects.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes. 
Please link to the article in which this freebie was released if you would like to spread the word.

http://creativecommons.org/licenses/by-sa/3.0/

Smashing Magazine Team,
www.smashingmagazine.com
